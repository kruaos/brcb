  <?php 
// include('../config/config.php');

//  $sql_select="SELECT * FROM  `bankevent` WHERE  `bankid` LIKE  '-%' ";
//  $q_select = mysqli_query($link, $sql_select);
//  while($rs_se = mysqli_fetch_array($q_select))
//        {
//  $num=$rs_se['num'];
//  $update="update bankevent set bank_event_status='0' where num=$num";
//  mysqli_query($link, $update);
//        }

//  echo 'is ok';
  ?>