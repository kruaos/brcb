<?php
ob_start();

session_start();
session_id();
include('../tmp_dsh2/header.php');
include('navbar.php');
include('menu.php');
include('../config/config.php');


unset($_SESSION['IDMember']);

$employee_use = $_SESSION['employee_USER'];
$IDMember = $_POST['IDMember_Dep'];
// $DepPage = $_SESSION['DepPage'];


$ShowMember = "select m.Title, m.Firstname, m.Lastname, m.MemberStatus 
from Member as m where  m.IDMember=$IDMember";
$SMQuery = mysqli_query($link, $ShowMember);
if ($IDMember == null) {
  echo "กรุณากรอกรหัสสมาชิก  <br>  ";
  echo "<a href='dep-pay-tool.php'>ย้อนกลับ</a>";
  exit();
} else if (mysqli_num_rows($SMQuery) == 0) {
  echo "รหัสสมาชิกไม่ถูกต้อง <br>";
  echo "ไม่พบรหัส " . $IDMember . " ในฐานข้อมูล <br>";
  echo "<a href='dep-pay-tool.php'>ย้อนกลับ</a>";
  exit();
}
while ($SM = mysqli_fetch_array($SMQuery)) {
  $FullNameMember = $SM['Title'] . $SM['Firstname'] . " " . $SM['Lastname'];
}
$n = 1;
$ShowRegfund = "select * from regfund where  IDMember=$IDMember order by IDFund ASC";
$SRfQuery = mysqli_query($link, $ShowRegfund);


while ($SRf = mysqli_fetch_array($SRfQuery)) {
  $SRFArray[$n]['IDRegFund'] = $SRf['IDRegFund'];
  $SRFArray[$n]['IDFund'] = $SRf['IDFund'];
  $SRFArray[$n]['LastUpdate'] = $SRf['LastUpdate'];
  $SRFArray[$n]['Closedate'] = $SRf['Closedate'];
  $SRFArray[$n]['Balance'] = $SRf['Balance'];
  $n++;
}


// print_r($SRFArray);

$ShowAmount1 = $SRFArray['1']['Balance'];
// select 
$ShowAmount2 = $SRFArray['2']['Balance'];

$Amount1 = 30;
$Amount2 = 5;

$TodayDate = date('Y-m-d');
$IDRegFund1 = $SRFArray['1']['IDRegFund'];
$SqlCheckInput = "SELECT d.*, e.firstname, e.lastname  FROM deposit as d , employee as e where d.IDRegFund=$IDRegFund1 and d.createdate='$TodayDate' and d.username=e.username";
$CheckInputQuery = mysqli_query($link, $SqlCheckInput);
// echo $SqlCheckInput;
// print_r($CheckInputQuery);
// exit(); 
$CheckInputNumrows = mysqli_num_rows($CheckInputQuery);

?>
<script type="text/javascript">
  function clicked() {
    alert('clicked');
  }
</script>
<div class="container-fluid ">
  <div class="row">
    <div class="p-3 mb-2 col bg-primary">
      <h1 class="display-6">ระบบฝากสัจจะ </h1>
      <?php
      echo "รหัสเจ้าหน้าที่ : " . $employee_use;
      echo " [ แผ่นที่ " . $DepPage . " ] ";
      ?>
    </div>
  </div>
  <div class="row">
    <div class="col col-sm-12 col-md-4 col-lg-4 ">
      <form action="#">
        <div class="form-group">
          <label>รหัสสมาชิก</label>
          <input type="text" class="form-control " value="<?php echo $IDMember; ?>" disabled>
        </div>
      </form>
      <?php
      if ($CheckInputNumrows <> 0) {
        // แจ้งว่ามีการฝากแล้ว 

        while ($CIQ = mysqli_fetch_array($CheckInputQuery)) {
          $showUsername = $CIQ['firstname'] . "  " . $CIQ['lastname'];
          // print_r($RQCT);
        }
      ?>
        <div class="alert alert-danger" role="alert">
          มีการฝากแล้วโดย
          <?php
          echo $showUsername;
          ?>
        </div>

        <div class="form-group">
          <label>ข้อมูลสมาชิก</label>
          <input class="form-control " type="text" value="<?php echo $FullNameMember; ?>" disabled>
          <input class="form-control " type="text" value="เงินฝากสัจจะ : <?php echo number_format($ShowAmount1, 2); ?>" disabled>
          <input class="form-control " type="text" value="เงินฝากเพื่อนช่วยเพื่อน : <?php echo number_format($ShowAmount2, 2); ?>" disabled>

        <?php
      } else {
        ?>
          <form method="POST" action="dep-pay-add.php">
            <div class="form-group">
              <label>ข้อมูลสมาชิก</label>
              <input class="form-control " type="text" value="<?php echo $FullNameMember; ?>" disabled>
              <input class="form-control " type="text" value="เงินฝากสัจจะ : <?php echo number_format($ShowAmount1, 2); ?>" disabled>
              <input class="form-control " type="text" value="เงินฝากเพื่อนช่วยเพื่อน : <?php echo number_format($ShowAmount2, 2); ?>" disabled>
              <label>ฝากสัจจะ</label>
              <input class="form-control " type="number" name="Amount1" value="<?php echo $Amount1; ?>" style="font-size:30px; text-align:right" min="30" max="30" required>
              <label>ฝากเพื่อนช่วยเพื่อน</label>
              <!-- <select class="fcustom-select "  name="Amount2"  
            style="font-size:20px; text-align:right" onKeyUp="if(isNaN(this.value)){ alert('กรุณากรอกตัวเลข'); this.value='';}"
             onfocus="this.value = this.value;" autofocus>
              <option value='5' >5</option>
              <option value='10'>10</option>
              <option value='15'>15</option>
            </select> -->

              <input class="form-control " type="number" name="Amount2" value="<?php echo $Amount2; ?>" style="font-size:30px; text-align:right" value='5' min="0" max="20" step="5" onfocus="this.value = this.value;" autofocus required>

              <input type="hidden" name="Fullname" value="<?php echo $FullNameMember; ?>">
              <input type="hidden" name="IDMember" value="<?php echo $IDMember; ?>">
              <input type="hidden" name="DepPage" value="<?php echo $DepPage; ?>">
              <br>
              <input type="submit" class="form-control btn-success " value="ฝาก">
            <?php
          }
            ?>
            </div>
          </form>
          <a href="dep-pay-tool.php" class="form-control btn btn-danger">ยกเลิก</a>
        </div>
        <div class="col col-sm-12 col-md-8 col-lg-8 ">

        </div>
        <?PHP
        include('../tmp_dsh2/table.php');
        include('../tmp_dsh2/footer.php');
        ?>