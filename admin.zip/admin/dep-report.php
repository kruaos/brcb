<?php
include('../tmp_dsh2/header.php');
include('navbar.php');
include('menu.php');
include('../config/config.php');

function show_day($showday)
{
    $m_name = array("", "ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค.");
    return number_format(substr($showday, 8, 2)) . " " . $m_name[number_format(substr($showday, 5, 2))] . " " . (substr($showday, 0, 4) + 543);
}

// รับค่าจากแบบฟอร์มหรือใช้วันที่ปัจจุบัน
$DateNow = isset($_POST['selected_date']) ? $_POST['selected_date'] : date('Y-m-d');
$TotalSumAmountDep = 0;
$TotalSumAmountIns = 0;

?>

<div class="container-fluid">
    <div class="display-3">รายงานการส่งเงินสัจจะ</div>
    <div class="display-4">ประจำวันที่ <?php echo show_day($DateNow); ?></div>

    <!-- ฟอร์มเลือกวันที่ -->
    <form method="POST" class="mb-3 d-print-none">
        <label for="selected_date">เลือกวันที่:</label>
        <input type="date" id="selected_date" name="selected_date" value="<?php echo $DateNow; ?>">
        <button type="submit" class="btn btn-primary">แสดงข้อมูล</button>
    </form>

    <?php
    // รวมการ query ในระดับฐานข้อมูล
    $query = "
        SELECT 
            d.Username,
            e.Firstname,
            e.Lastname,
            COUNT(d.Amount) AS CountAmount,
            SUM(CASE WHEN d.Amount = 30 THEN d.Amount ELSE 0 END) AS SumAmountDep,
            SUM(CASE WHEN d.Amount != 30 THEN d.Amount ELSE 0 END) AS SumAmountIns,
            SUM(d.Amount) AS TotalAmount
        FROM deposit d
        LEFT JOIN employee e ON d.Username = e.Username
        WHERE d.CreateDate = '$DateNow'
        GROUP BY d.Username, e.Firstname, e.Lastname
    ";
    $result = mysqli_query($link, $query);
    ?>

    <table class="table table-hover">
        <thead>
            <tr>
                <th>ที่</th>
                <th>เจ้าหน้าที่</th>
                <th style="text-align: center;">จำนวนราย</th>
                <th style="text-align: right;">ยอดฝากสัจจะ</th>
                <th style="text-align: right;">ยอด พชพ</th>
                <th style="text-align: right;">ยอดเงินรวม</th>
                <th style="text-align: center;">จัดการ</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $num = 1;
            while ($row = mysqli_fetch_assoc($result)) {
                $fullname = $row['Firstname'] . " " . $row['Lastname'];
                $TotalCountAmount += $row['CountAmount'];
                $TotalSumAmountDep += $row['SumAmountDep'];
                $TotalSumAmountIns += $row['SumAmountIns'];
                $TotalSumAmount = $TotalSumAmountDep + $TotalSumAmountIns;
            ?>
                <tr>
                    <td><?php echo $num++; ?></td>
                    <td><?php echo $fullname; ?></td>
                    <td style="text-align: center;"><?php echo number_format($row['CountAmount']); ?></td>
                    <td style="text-align: right;"><?php echo number_format($row['SumAmountDep'], 2); ?></td>
                    <td style="text-align: right;"><?php echo number_format($row['SumAmountIns'], 2); ?></td>
                    <td style="text-align: right;"><?php echo number_format($row['TotalAmount'], 2); ?></td>
                    <td style="text-align: center;">
                        <a class="btn btn-warning d-print-none" href="dep-report-user.php?Username=<?php echo $row['Username']; ?>&DepDate=<?php echo $DateNow; ?>">รายการทั้งหมด</a>
                        <a class="btn btn-success d-print-none" href="dep-report-user-send.php?Username=<?php echo $row['Username']; ?>&DepDate=<?php echo $DateNow; ?>">ส่งรายงาน</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
        <tfoot>
        <tr class="table-active">
            <td></td>
            <td></td>
            <td></td>
            <td colspan="2">จำนวนสมาชิกฝากจำวัน </td>
            <td style='text-align:right'>
                <?php echo Number_format($TotalCountAmount, 0); ?>
            </td>
            <td>ราย</td>
        </tr>
        <tr class="table-active">
            <td></td>
            <td></td>
            <td></td>
            <td colspan="2">รวมเงินฝากสัจจะ</td>
            <td style='text-align:right'>
                <?php echo number_format($TotalSumAmountDep, 2); ?>
            </td>
            <td>บาท</td>
        </tr>
        <tr class="table-active">
            <td></td>
            <td></td>
            <td></td>
            <td colspan="2">รวมเงินฝากเพื่อนช่วยเพื่อน</td>
            <td style='text-align:right'>
                <div style="font-size:16px"><?php echo number_format($TotalSumAmountIns, 2); ?></div>
            </td>
            <td>บาท</td>
        </tr>
        <tr class="table-active">
            <td></td>
            <td></td>
            <td></td>
            <td colspan="2">ผลรวม</td>
            <td style='text-align:right'>
                <div style="font-size:16px"><?php echo number_format($TotalSumAmount, 2); ?></div>
            </td>
            <td>บาท</td>
        </tr>
        </tfoot>
    </table>

    <button class="btn btn-danger col d-print-none" onclick="window.print()">พิมพ์รายงาน</button>
</div>

<?php
include('../tmp_dsh2/table.php');
include('../tmp_dsh2/footer.php');
?>
