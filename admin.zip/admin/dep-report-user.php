<?php
include('../tmp_dsh2/header.php');
include('navbar.php');
include('menu.php');
include('../config/config.php');

// รับค่าตัวแปรผ่าน GET และป้องกัน SQL Injection
$Username = isset($_GET['Username']) ? mysqli_real_escape_string($link, $_GET['Username']) : '';
$DepDate = isset($_GET['DepDate']) ? mysqli_real_escape_string($link, $_GET['DepDate']) : date('Y-m-d');

// ตรวจสอบว่า $DepDate เป็นรูปแบบวันที่ที่ถูกต้อง
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $DepDate)) {
    $DepDate = date('Y-m-d');
}

// ฟังก์ชันแปลงวันที่เป็นภาษาไทย
function show_day($showday)
{
    $m_name = array("", "ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค.");
    return number_format(substr($showday, 8, 2)) . " " . $m_name[number_format(substr($showday, 5, 2))] . " " . (substr($showday, 0, 4) + 543);
}

// Query เพื่อดึงข้อมูล
$sql = "
    SELECT m.IDMember, m.Firstname, m.Lastname, d.IDRegFund, d.Amount, d.CreateDate, d.DepositStatus 
    FROM deposit AS d
    JOIN regfund AS r ON d.IDRegFund = r.IDRegFund
    JOIN member AS m ON r.IDMember = m.IDMember
    WHERE d.CreateDate = '$DepDate' AND d.Username = '$Username'
    ORDER BY m.IDMember, d.IDRegFund ASC";

$querydep = mysqli_query($link, $sql);

// จัดกลุ่มข้อมูลตาม IDMember
$data = array();
while ($row = mysqli_fetch_assoc($querydep)) {
    $IDMember = $row['IDMember'];
    if (!isset($data[$IDMember])) {
        $data[$IDMember] = array(
            'IDMember' => $IDMember,
            'Name' => $row['Firstname'] . " " . $row['Lastname'],
            'Funds' => array()
        );
    }
    $data[$IDMember]['Funds'][] = array(
        'IDRegFund' => $row['IDRegFund'],
        'Amount' => $row['Amount'],
        'Date' => show_day($row['CreateDate']),
        'Status' => $row['DepositStatus']
    );
}

?>
<div class="container-fluid">
    <h6 class="m-0 font-weight-bold text-primary">รายละเอียดสมาชิกสัจจะ จาก deposit</h6>

    <!-- ฟอร์มเลือกวันที่ -->
    <form method="GET" class="mt-3">
        <input type="hidden" name="Username" value="<?php echo htmlspecialchars($Username); ?>">
        <label for="DepDate">เลือกวันที่:</label>
        <input type="date" id="DepDate" name="DepDate" value="<?php echo htmlspecialchars($DepDate); ?>">
        <button type="submit" class="btn btn-primary">แสดงข้อมูล</button>
    </form>

    <div class="row mt-3">
        <button class="btn btn-danger col d-print-none" onclick="window.print()">พิมพ์รายงาน</button>

        <table class="table table-sm" cellspacing="0" style="font-size: 20px;">
            <thead>
                <tr>
                    <th>รหัสสมาชิก</th>
                    <th>ชื่อ-นามสกุล</th>
                    <th>RegFund1</th>
                    <th>จำนวน</th>
                    <th>RegFund2</th>
                    <th>จำนวน</th>
                    <th>RegFund3</th>
                    <th>จำนวน</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $member): ?>
                    <tr>
                        <td style='text-align:center'><?php echo $member['IDMember']; ?></td>
                        <td><?php echo $member['Name']; ?></td>
                        <?php
                        $funds = $member['Funds'];
                        for ($i = 0; $i < 3; $i++) {
                            if (isset($funds[$i])) {
                                echo "<td style='text-align:center' >" . htmlspecialchars($funds[$i]['IDRegFund']) . "</td>";
                                echo "<td style='text-align:right'>" . number_format($funds[$i]['Amount'], 2) . "</td>";
                            } else {
                                echo "<td></td><td></td>";
                            }
                        }
                        ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
mysqli_close($link);
include('../tmp_dsh2/footer.php');
?>
