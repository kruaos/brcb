<?php 
include('../tmp_dsh2/header.php');
include('navbar.php');
include('menu.php');
?>
<div class="container-fluid">




<h1 class="display-1">loan-pay</h1>
<li> <a href="loan-pay-tool.php"> ชำระเงินกู้ </a></li>




</div>
<?PHP 
include('../tmp_dsh2/table.php');
include('../tmp_dsh2/footer.php');
?>