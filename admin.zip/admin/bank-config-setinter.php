<?php
switch ($m) {
    case 1: $mt12=array(0,1); break;
    case 2: $mt12=array(0,2); break;
    case 3: $mt12=array(0,3); break;
    case 4: $mt12=array(0,4); break;
    case 5: $mt12=array(0,5); break;
    case 6: $mt12=array(0,6); break;
    case 7: $mt12=array(0,7); break;
    case 8: $mt12=array(0,8); break;
    case 9: $mt12=array(0,9); break;
    case 10: $mt12=array(0,10); break;
    case 11: $mt12=array(0,11); break;
    case 12: $mt12=array(0,12); break;
    default: echo "การคำนานผิดพลาด";
}
switch ($m) {
    case 1: $mt3=array(0,4,7,10,1); break;
    case 2: $mt3=array(0,5,8,11,2); break;
    case 3: $mt3=array(0,6,9,12,3); break;
    case 4: $mt3=array(0,7,10,1,4); break;
    case 5: $mt3=array(0,8,11,2,5); break;
    case 6: $mt3=array(0,9,12,3,6); break;
    case 7: $mt3=array(0,10,1,4,7); break;
    case 8: $mt3=array(0,11,2,5,8); break;
    case 9: $mt3=array(0,12,3,6,9); break;
    case 10: $mt3=array(0,1,4,7,10); break;
    case 11: $mt3=array(0,2,5,8,11); break;
    case 12: $mt3=array(0,3,6,9,12); break;
    default: echo "การคำนานผิดพลาด";
}
switch ($m) {
    case 1:  $mty=array(0,0,0,0,1); break;
    case 2:  $mty=array(0,0,0,0,1); break;
    case 3:  $mty=array(0,0,0,0,1); break;
    case 4:  $mty=array(0,0,0,1,0); break;
    case 5:  $mty=array(0,0,0,1,0); break;
    case 6:  $mty=array(0,0,0,1,0); break;
    case 7:  $mty=array(0,0,1,0,0); break;
    case 8:  $mty=array(0,0,1,0,0); break;
    case 9:  $mty=array(0,0,1,0,0); break;
    case 10: $mty=array(0,1,0,0,0); break;
    case 11: $mty=array(0,1,0,0,0); break;
    case 12: $mty=array(0,1,0,0,0); break;
    default: echo "การคำนานผิดพลาด"; 
}

?>